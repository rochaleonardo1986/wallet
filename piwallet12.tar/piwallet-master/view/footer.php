<?php if (!defined("IN_WALLET")) { die("Auth Error!."); } ?>
<?php //PLEASE DO NOT REMOVE OR CHANGE THE POWERED BY LINK. THIS IS THE ONLY RECOGNITION I ASK FOR ?>
            </div>
        </div>

    </body>
<b><center><p>Powered by <a href="http://github.com/johnathanmartin/piWallet" target="_blank">piWallet</a> e Adaptado por <a href="http://www.levinobre.com" target="_blank">Levi Nobre</a> (<a href="http://martexcoin.org/forum/index.php?topic=4.0" target="_blank">Martexcoin Core Developers</a>)</p>
</center></b>
</html>
